export interface FavoriteCreateInput {
  readonly restaurantId: string;
  readonly userId: string;
}
