import { FirebaseGuard } from './firebase.guard';

describe('FirebaseGuard', () => {
  it('should be defined', () => {
    expect(new FirebaseGuard()).toBeDefined();
  });
});
