import React from "react";
import ReservationComp from "./ShowReservations";
import "../App.css";

function ShowReservations() {
  return (
    <div>
      <ReservationComp />
    </div>
  );
}

export default ShowReservations;
