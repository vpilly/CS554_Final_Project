import React from "react";
import CreateResButton from "./CreateRestaurant";
import "../App.css";

function ResCreate() {
  return (
    <div>
      <h2>Restaurant Creation Page</h2>
      <CreateResButton />
    </div>
  );
}

export default ResCreate;
